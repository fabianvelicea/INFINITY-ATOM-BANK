ATENȚIE PENTRU CA PROGRAMUL SĂ FUNCȚIONEZE,la adresa
AppData\Roaming (Mai simplu: %appdata%)\AtomB (Acest folder trebuie creat) (Adresa completa: %appdata%\AtomB), atașați fișierul 0000.txt
Și conectați-vă cu contul 0000 și pin-ul 1234